#!/bin/bash

CLIENT_ID="j2eaj1gxokr77a3lrzso63tr6wvk22"
CLIENT_SECRET="k8f8xxds7yy6rwe7upsc36rttw1bgx"
REFRESH_TOKEN="jj1xzv86yfwh1g7024wcluzh3vu34hkw25pdllsznly0sgf925"
TOKEN_FILE="/home/ubuntu/twitch_token.txt"
LOG="/home/ubuntu/refresh-token.log"

RESPONSE=$(curl -s -X POST https://id.twitch.tv/oauth2/token \
  -d client_id=$CLIENT_ID \
  -d client_secret=$CLIENT_SECRET \
  -d grant_type=refresh_token \
  -d refresh_token=$REFRESH_TOKEN)

NEW_ACCESS=$(echo $RESPONSE | jq -r '.access_token')
NEW_REFRESH=$(echo $RESPONSE | jq -r '.refresh_token')

if [ "$NEW_ACCESS" != "null" ] && [ -n "$NEW_ACCESS" ]; then
    echo "$NEW_ACCESS" > $TOKEN_FILE
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Token rafraîchi avec succès" >> $LOG

    if [ "$NEW_REFRESH" != "null" ] && [ -n "$NEW_REFRESH" ]; then
        # Met à jour le refresh token dans ce script
        sed -i "s|REFRESH_TOKEN="jj1xzv86yfwh1g7024wcluzh3vu34hkw25pdllsznly0sgf925"
    fi
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Échec du refresh" >> $LOG
    echo "$RESPONSE" >> $LOG
fi
