#!/bin/bash

CLIENT_ID="j2eaj1gxokr77a3lrzso63tr6wvk22"
ACCESS_TOKEN=$(cat /home/ubuntu/twitch_token.txt)
BROADCASTER_ID="426411773"
LOG="/home/ubuntu/delete-vods.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Recherche des VODs Offline..." >> $LOG

# Récupérer les 20 dernières vidéos
VIDEOS=$(curl -s -H "Client-ID: $CLIENT_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  "https://api.twitch.tv/helix/videos?user_id=$BROADCASTER_ID&first=20&type=archive")

# Extraire les IDs des vidéos dont le titre contient "Offline"
IDS=$(echo "$VIDEOS" | jq -r '.data[] | select(.title | test("Offline|test|Test de stream"; "i")) | .id')

if [ -z "$IDS" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Aucun VOD Offline trouvé" >> $LOG
    exit 0
fi

# Supprimer les VODs (max 5 à la fois)
for ID in $IDS; do
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Suppression du VOD $ID" >> $LOG
    curl -s -X DELETE "https://api.twitch.tv/helix/videos?id=$ID" \
      -H "Client-ID: $CLIENT_ID" \
      -H "Authorization: Bearer $ACCESS_TOKEN" >> $LOG
    echo "" >> $LOG
    sleep 1
done

echo "$(date '+%Y-%m-%d %H:%M:%S') - Nettoyage terminé" >> $LOG
